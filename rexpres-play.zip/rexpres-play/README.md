# Rexpres Play — Tienda de recargas Free Fire

Sitio estático (HTML + CSS + JS puro, sin frameworks) para vender diamantes de Free Fire.
Está pensado para cargar rápido en celular y computadora, y para publicarse directo en **GitHub Pages**.

## Estructura del proyecto

```
rexpres-play/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── main.js
├── assets/
│   └── favicon.svg
└── README.md
```

## Antes de publicar — cosas que debes cambiar

1. **Número de WhatsApp**: aparece en 3 lugares. Reemplaza `593000000000` por tu número real (con código de país, sin `+` ni espacios):
   - `js/main.js` → variable `WHATSAPP_NUMBER`
   - `index.html` → los dos enlaces `https://wa.me/593000000000`
2. **Correo de contacto**: en `index.html`, cambia `contacto@rexpresplay.com` por tu correo real.
3. **Precios de los paquetes**: en `index.html`, dentro de la sección `id="paquetes"`, edita los montos y precios de cada `<article class="pack-card">`.
4. **Métodos de pago** en la sección de preguntas frecuentes, ajusta el texto según lo que realmente aceptes (transferencia, Payphone, tarjeta, etc.).

## Cómo subirlo a GitHub y publicarlo con GitHub Pages

1. Crea un repositorio nuevo en GitHub (puede ser público o privado, GitHub Pages funciona con ambos si tienes plan compatible; para público es gratis siempre).
2. En tu computadora, dentro de esta carpeta `rexpres-play`, ejecuta:
   ```bash
   git init
   git add .
   git commit -m "Primera versión del sitio Rexpres Play"
   git branch -M main
   git remote add origin https://github.com/TU-USUARIO/TU-REPOSITORIO.git
   git push -u origin main
   ```
3. En GitHub, entra al repositorio → **Settings** → **Pages**.
4. En "Build and deployment", selecciona **Source: Deploy from a branch**.
5. En "Branch", elige **main** y la carpeta **/ (root)**. Guarda.
6. Espera uno o dos minutos. Tu sitio quedará publicado en:
   `https://TU-USUARIO.github.io/TU-REPOSITORIO/`

No necesitas build ni instalar nada: es HTML/CSS/JS plano, así que GitHub Pages lo sirve tal cual.

## Notas técnicas

- No usa frameworks ni dependencias externas salvo las fuentes de Google Fonts (Chakra Petch, Plus Jakarta Sans, JetBrains Mono), que se cargan por CDN.
- Totalmente responsive: probado desde ~320px de ancho (celular) hasta pantallas grandes.
- Respeta `prefers-reduced-motion` para quienes desactivan animaciones.
- El menú móvil, el scroll-reveal y el efecto del encabezado están en `js/main.js`, sin ninguna librería.
- Los botones "Comprar" abren WhatsApp con un mensaje ya redactado indicando el paquete elegido, para agilizar el pedido.
